const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/nodeRest',  { useNewUrlParser: true });
mongoose.Promise = global.Promise;

module.exports = mongoose;