const mongoose = require('../database');
const bcryptjs = require('bcryptjs');

const schema = mongoose.Schema;

const UserSchema = new schema({
    name: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
        lowercase: true,
        unique: true,
    },
    password: {
        type: String,
        required: true,
        select: false, // para quando o array contendo o usuario seja aberto, nao contenha essa info
    },
    createdAt: {
        type: Date,
        default: Date.now,
    }
});

UserSchema.pre('save', async function(next) {
    const hash = await bcryptjs.hash(this.password, 10);

    this.password = hash;

    next();
});

module.exports = mongoose.model('User', UserSchema);