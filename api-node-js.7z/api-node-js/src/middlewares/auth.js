const jwt = require('jsonwebtoken');
const AuthConfig = require('../config/auth.json');

module.exports = (req, res, next) => {
    const authHeaders = req.headers.authorization;

    if (!authHeaders) return res.status(401).send({ error: 'No token received' });
    // verificar se o token foi recebido

    const parts = authHeaders.split(' ');
    // dividir o token em duas partes: "Bearer" e o hash

    if (!parts.length === 2) return res.status(401).send({ error: 'Token error' });
    // verificar se a divisao foi um sucesso

    const [ scheme, token ] = parts;
    // armazenar essas duas partes

    if (!/^Bearer$/i.test(scheme)) return res.status(401).send({ error: 'Token format error' });
    // verificar se a primeira parte contem o termo padrao "Bearer"

    jwt.verify(token, AuthConfig.secret, (err, decoded) => {
        if (err) return res.status(401).send({ error: 'Invalid token' });
        
        req.userId = decoded.id;
        return next();
        // verificar se o token informado na requisicao bate com o token fornecido na autenticacao e, em caso afirmativo, passar o id do usuario para as proximas requisicoes
    });
}