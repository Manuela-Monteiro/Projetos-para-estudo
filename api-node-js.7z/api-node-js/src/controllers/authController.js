const mongoose = require('mongoose');
const express = require('express');

const User = require('../models/user');
const bcryptjs = require('bcryptjs');
const jwt = require('jsonwebtoken');

const authConfig = require('../config/auth');

const router = express.Router();

function generateToken(params = {}) {
    return token = jwt.sign(params,
            authConfig.secret,
            { expiresIn: 86400 },
            );
            // a funcao sign recebe o id do usuario, o codigo do json que individualiza a aplicacao e determina um tempo para que esse token expire (em segundos)
}

router.post('/register', async (request, response) => {
    const { email } = request.body;

    try {
        if (await User.findOne({ email })) 
            return response.status(400).send({ error: 'This user already exists' });

        const user = await User.create(request.body);

        user.password = undefined;

        return response.send({ user,
            token: generateToken({ id: user.id })
            });
    } catch (err) {
        return response.status(400).send({ error: 'Registration failed' }); // retorna mensagem de erro caso haja falha no registro
    }
});

router.post('/authenticate', async (request, response) => {
    const { email, password } = request.body; //coletar e-mail e senha informados no login

    const user = await User.findOne({ email }).select('+password'); //coletar e-mail e senha cadastrados e armazenados no BD

    if (!user) {
        return response.status(400).send({ error: 'User not found' });
    // verifica se os dados correspondem a um usuario que existe
    }

    if (!await bcryptjs.compare(password, user.password)) {
        return response.status(400).send({ error: 'Wrong e-mail or password' });
        // verifica se os dados informados no login batem com os dados presentes no BD, retornando uma mensagem de erro se nao bater
    }

    user.password = undefined;
    // remove a senha do retorno ao back-end
    
    response.send({ user,
        token: generateToken({ id: user.id })
    });
    // retorna os dados do usuario e o token gerado
});

module.exports =  app => app.use('/auth', router);